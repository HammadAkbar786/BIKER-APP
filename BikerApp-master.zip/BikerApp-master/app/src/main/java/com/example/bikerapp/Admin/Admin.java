package com.example.bikerapp.Admin;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.bikerapp.AddPost;
import com.example.bikerapp.Login;
import com.example.bikerapp.MainActivity;
import com.example.bikerapp.R;
import com.example.bikerapp.User.All_Posts;
import com.example.bikerapp.User.UserMain;

public class Admin extends AppCompatActivity {
    CardView addpost,category,manage;
    Button logout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        addpost=findViewById(R.id.admin_addpost);
        category=findViewById(R.id.admin_categories);
        manage=findViewById(R.id.admin_managepost);
        logout=findViewById(R.id.admin_logout);
        All_Posts.data="";
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Admin.this, MainActivity.class);
                startActivity(i);
            }
        });
        addpost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Admin.this, AddPost.class);
                i.putExtra("id","admin");
                startActivity(i);
            }
        });
        category.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i=new Intent(Admin.this, ManageCategories.class);
                startActivity(i);
            }
        });
        manage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Admin.this, Manage_Posts.class);
                i.putExtra("data","admin");
                startActivity(i);
            }
        });
    }
    @Override
    public void onBackPressed() {

    }
}