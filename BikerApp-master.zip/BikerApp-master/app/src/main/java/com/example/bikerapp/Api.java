package com.example.bikerapp;

public class Api {
    public static final String ROOT_URL = "http://192.168.0.107:80/";
}
