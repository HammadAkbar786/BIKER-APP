package com.example.bikerapp.User;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.bumptech.glide.Glide;
import com.example.bikerapp.AddPost;
import com.example.bikerapp.Admin.Manage_Posts;
import com.example.bikerapp.Api;
import com.example.bikerapp.R;
import com.example.bikerapp.UpdatePost;

import org.json.JSONObject;

import java.util.ArrayList;

public class Posts_Adapter extends RecyclerView.Adapter<Posts_Adapter.viewHolder> {

    Context context;
    ArrayList<Model_class> arrayList;

    public Posts_Adapter(Context context, ArrayList<Model_class> arrayList) {
        this.context = context;
        this.arrayList = arrayList;
    }

    @Override
    public Posts_Adapter.viewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_model, viewGroup, false);
        return new Posts_Adapter.viewHolder(view);
    }

    @Override
    public void onBindViewHolder(Posts_Adapter.viewHolder viewHolder, int position) {
        viewHolder.price.setText(arrayList.get(position).getPrice());
        viewHolder.desc.setText(arrayList.get(position).getDescription());
        viewHolder.id.setText(arrayList.get(position).getId());
        viewHolder.category.setText(arrayList.get(position).getCategory());

        Glide.with(viewHolder.image)
                .load(arrayList.get(position).getImageUrl())
                .fitCenter()
                .into(viewHolder.image);
        viewHolder.name.setText(arrayList.get(position).getName());
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView price;
        TextView desc;
        TextView name, id, category, type, season;
        CardView itemcard;

        public viewHolder(View itemView) {
            super(itemView);
            category = itemView.findViewById(R.id.item_category);

            id = itemView.findViewById(R.id.item_id);
            name = itemView.findViewById(R.id.item_name);
            image = itemView.findViewById(R.id.item_img);
            price = itemView.findViewById(R.id.item_price);
            desc = itemView.findViewById(R.id.item_desc);
            itemcard = itemView.findViewById(R.id.item_card);
            itemcard.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(final View v) {
                    if(All_Posts.data.equals("allposts")){
//                        Toast.makeText(context, "", Toast.LENGTH_SHORT).show();
                    }
                    else if(Manage_Posts.data.equals("admin"))
                    {
                        AlertDialog.Builder builder = new AlertDialog.Builder(v.getRootView().getContext());
                        builder.setTitle("Actions on item");
                        builder.setItems(new CharSequence[]
                                        {"Edit Item", "Delete Item", "Cancel"},
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        // The 'which' argument contains the index position
                                        // of the selected item
                                        switch (which) {
                                            case 0:
                                                Intent intent = new Intent(context, UpdatePost.class);
                                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                                intent.putExtra("id",id.getText().toString());
                                                context.startActivity(intent);



                                                break;
                                            case 1:
                                                deleteitem();
                                                break;
                                            case 2:

                                                break;

                                        }
                                    }
                                });
                        builder.create().show();
                    }
                    else{
                        AlertDialog.Builder builder = new AlertDialog.Builder(v.getRootView().getContext());
                        builder.setTitle("Actions on item");
                        builder.setItems(new CharSequence[]
                                        {"Edit Item", "Delete Item", "Cancel"},
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        // The 'which' argument contains the index position
                                        // of the selected item
                                        switch (which) {
                                            case 0:
                                                Intent intent = new Intent(context, UpdatePost.class);
                                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                                intent.putExtra("id",id.getText().toString());
                                                context.startActivity(intent);



                                                break;
                                            case 1:
                                                deleteitem();
                                                break;
                                            case 2:

                                                break;

                                        }
                                    }
                                });
                        builder.create().show();
                    }

//                    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialog, int which) {
//                            switch (which) {
//                                case DialogInterface.BUTTON_POSITIVE:
//                                    //Yes button clicked
//                                    break;
//
//                                case DialogInterface.BUTTON_NEGATIVE:
//                                    //No button clicked
//                                    break;
//                            }
//                        }
//                    };
//                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
//                    builder.setMessage("Do You want to edit this product?").setPositiveButton("Yes", dialogClickListener)
//                            .setNegativeButton("No", dialogClickListener).show();
//                    Toast.makeText(v.getContext(),price.getText().toString(), Toast.LENGTH_SHORT).show();

                }
            });

        }
        public void deleteitem() {

            AndroidNetworking.post(Api.ROOT_URL+"biker/deletepostbyid.php")
                    .addBodyParameter("id", id.getText().toString())
                    .setTag("test")
                    .setPriority(Priority.MEDIUM)
                    .build()
                    .getAsJSONObject(new JSONObjectRequestListener() {
                        @Override
                        public void onResponse(JSONObject response) {

                            Toast.makeText(context, "Item has been deleted", Toast.LENGTH_SHORT).show();

                            Intent intent = new Intent(context, All_UserPosts.class);
                            intent.putExtra("id",All_UserPosts.id);
                            context.startActivity(intent);

                        }

                        @Override
                        public void onError(ANError error) {
                            // handle error
                        }
                    });
        }
    }

}

