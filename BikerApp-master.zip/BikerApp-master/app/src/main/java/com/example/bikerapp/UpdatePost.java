package com.example.bikerapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.SparseIntArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.androidnetworking.interfaces.StringRequestListener;
import com.androidnetworking.interfaces.UploadProgressListener;
import com.bumptech.glide.Glide;
import com.example.bikerapp.R;
import com.example.bikerapp.User.All_Posts;
import com.example.bikerapp.User.All_UserPosts;
import com.example.bikerapp.User.UserMain;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class UpdatePost extends AppCompatActivity {
    EditText name,price,details;
    Button addpost,updatepost;
    Spinner category;
    String selectedvalue;
    ImageView item_image;
    String filePath="";
    String id;
    File filetoupload;
    List<String> spinnerArray =  new ArrayList<String>();
    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_post);
        name=findViewById(R.id.update_product_name);
        price=findViewById(R.id.update_product_price);
        details=findViewById(R.id.update_product_Description);
        updatepost=findViewById(R.id.update_product);
        category=findViewById(R.id.update_category);
        showcategories();

        item_image=findViewById(R.id.update_item_image);
        category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedvalue=parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        Bundle b=getIntent().getExtras();
        id=b.getString("id");
        Toast.makeText(UpdatePost.this, id, Toast.LENGTH_SHORT).show();
        updatepost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callapi(filetoupload);
            }
        });
        item_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectImage();
            }
        });
        showdata();
        
        
    }
    public void showcategories()
    {
        AndroidNetworking.post(Api.ROOT_URL+"biker/getallcategories.php")
                .setTag("test")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            Toast.makeText(UpdatePost.this, response+"", Toast.LENGTH_SHORT).show();
                            for (int i = 0; i < response.getJSONArray("allcategories").length(); i++)
                            {

                                spinnerArray.add(response.getJSONArray("allcategories").getJSONObject(i).getString("categories"));
                            }



                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
        switch (requestCode) {
            case 0:
                if (resultCode == RESULT_OK) {
                    Bundle extras = imageReturnedIntent.getExtras();
                    Bitmap imageBitmap = (Bitmap) extras.get("data");
                    item_image.setImageBitmap(imageBitmap);
                    Uri tempUri = getImageUri(getApplicationContext(), imageBitmap);
                    String path=getRealPathFromURI(tempUri);
                    filetoupload=new File(path);

//                    uploadBitmap(imageBitmap);
//                    uploadFile("" + getRealPathFromURI(tempUri));
                    Toast.makeText(this, "" + getRealPathFromURI(tempUri), Toast.LENGTH_SHORT).show();
                }

                break;
            case 1:
                if (resultCode == RESULT_OK) {
                    Uri selectedImage = imageReturnedIntent.getData();
                    filePath = getRealPathFromURI(selectedImage);
                    File f=new File(filePath);
                    Bitmap image=decodeFile(f);
                    Uri tempUri = getImageUri(getApplicationContext(), image);
                    String path=getRealPathFromURI(tempUri);
                    filetoupload=new File(path);


                    Toast.makeText(this, "" + getRealPathFromURI(selectedImage), Toast.LENGTH_SHORT).show();
                    item_image.setImageURI(selectedImage);
                }
                break;
        }
    }
    private Bitmap decodeFile(File f) {
        try {
            // Decode image size
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(new FileInputStream(f), null, o);

            // The new size we want to scale to
            final int REQUIRED_SIZE=100;

            // Find the correct scale value. It should be the power of 2.
            int scale = 1;
            while(o.outWidth / scale / 2 >= REQUIRED_SIZE &&
                    o.outHeight / scale / 2 >= REQUIRED_SIZE) {
                scale *= 2;
            }

            // Decode with inSampleSize
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            return BitmapFactory.decodeStream(new FileInputStream(f), null, o2);
        } catch (FileNotFoundException e) {}
        return null;
    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "pic", null);
        return Uri.parse(path);
    }

    public String getRealPathFromURI(Uri uri) {
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
        cursor.moveToFirst();
        int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
        return cursor.getString(idx);
    }

    private void selectImage() {
        final CharSequence[] options = {"Take Photo", "Choose from Gallery", "Cancel"};
        AlertDialog.Builder builder = new AlertDialog.Builder(UpdatePost.this);
        builder.setTitle("Add Photo!");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int item) {
                if (options[item].equals("Take Photo")) {
//                    File file = new File(path);
//                    Uri outputFileUri = Uri.fromFile(file);
                    Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(takePicture, 0);
                } else if (options[item].equals("Choose from Gallery")) {
                    Intent pickPhoto = new Intent(Intent.ACTION_PICK,
                            android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(pickPhoto, 1);
                } else if (options[item].equals("Cancel")) {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    public void callapi(File imageFile)
    {
        AndroidNetworking.upload(Api.ROOT_URL+"biker/updatepost.php")
                .addMultipartFile("file", imageFile)
                .addMultipartParameter("name",name.getText().toString())
                .addMultipartParameter("price",price.getText().toString())
                .addMultipartParameter("details",details.getText().toString())
                .addMultipartParameter("category",selectedvalue)

                .addMultipartParameter("id", id)
                //.setTag("uploadTest")
                .setPriority(Priority.HIGH)
                .build()
                .setUploadProgressListener(new UploadProgressListener() {
                    @Override
                    public void onProgress(long bytesUploaded, long totalBytes) {
                        // do anything with progress
//                        tvProgress.setText((bytesUploaded / totalBytes)*100 + " %");
                    }
                })
                .getAsString(new StringRequestListener() {
                    @Override
                    public void onResponse(String response) {

                        Toast.makeText(UpdatePost.this, "Post Added", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(UpdatePost.this, UserMain.class);
                        startActivity(intent);
                    }

                    @Override
                    public void onError(ANError anError) {
                        Toast.makeText(UpdatePost.this, anError.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });




    }
    public void showdata()
    {
//        Toast.makeText(UpdatePost.this, "here", Toast.LENGTH_SHORT).show();
        AndroidNetworking.post(Api.ROOT_URL+"biker/postbyid.php")
                .addBodyParameter("id",id)
                .setTag("test")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {
                            for (int i = 0; i < response.getJSONArray("post").length(); i++)
                            {
                                Glide.with(UpdatePost.this)
                                    .load(Api.ROOT_URL+"biker/"+response.getJSONArray("post").getJSONObject(i).getString("image_location"))
                                    .into(item_image);
                                name.setText(response.getJSONArray("post").getJSONObject(i).getString("name"));
                                price.setText(response.getJSONArray("post").getJSONObject(i).getString("price"));
                                details.setText(response.getJSONArray("post").getJSONObject(i).getString("details"));
                                String s_category = response.getJSONArray("post").getJSONObject(i).getString("category");
                                adapter= new ArrayAdapter<String>(UpdatePost.this, android.R.layout.simple_spinner_item, spinnerArray);

                                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                                category.setAdapter(adapter);
                            if (s_category != null) {
                                int spinnerPosition = adapter.getPosition(s_category);
                                category.setSelection(spinnerPosition);
                            }


                            }
                            Toast.makeText(UpdatePost.this, ""+response, Toast.LENGTH_SHORT).show();
//


//

                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }

}