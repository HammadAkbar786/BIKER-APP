package com.example.bikerapp.User;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.bikerapp.AddPost;
import com.example.bikerapp.Admin.Admin;
import com.example.bikerapp.Admin.Manage_Posts;
import com.example.bikerapp.Login;
import com.example.bikerapp.MainActivity;
import com.example.bikerapp.R;

public class UserMain extends AppCompatActivity {
    CardView addpost,mypost,allpost;
   String id;
   Button logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_main);
        addpost=findViewById(R.id.addpost);
        mypost=findViewById(R.id.mypost);
        allpost=findViewById(R.id.allpost);
        logout=findViewById(R.id.user_logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(UserMain.this, MainActivity.class);
                startActivity(i);
            }
        });
        Bundle b=getIntent().getExtras();
        id=b.getString("id");
        Toast.makeText(UserMain.this, id+"", Toast.LENGTH_SHORT).show();
        addpost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(UserMain.this, AddPost.class);
                i.putExtra("id",id);
                startActivity(i);
            }
        });
        mypost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(UserMain.this, All_UserPosts.class);
                i.putExtra("id",id);
                startActivity(i);
            }
        });
        allpost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i=new Intent(UserMain.this, All_Posts.class);
                i.putExtra("data","allposts");
                startActivity(i);
            }
        });

    }

    @Override
    public void onBackPressed() {

    }
}