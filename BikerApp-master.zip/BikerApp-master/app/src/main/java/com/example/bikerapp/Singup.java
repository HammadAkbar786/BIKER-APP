package com.example.bikerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.Signature;

public class Singup extends AppCompatActivity {
    TextView login;
    Button signup;
    EditText email,pass,fname,lname;
    RadioGroup radioGroup;
    String selectedvalue;
    String gender;
    boolean valid = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_singup);
        login=findViewById(R.id.p_tv_login);
        radioGroup=findViewById(R.id.rgroup);
        email=findViewById(R.id.et_email);
        pass=findViewById(R.id.et_pass);
        fname=findViewById(R.id.et_fname);
        lname=findViewById(R.id.et_l_name);
        signup=findViewById(R.id.signup);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

validate();
            }
        });
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // find which radio button is selected
                if(checkedId == R.id.r_male) {
                    gender ="male";
                } else if(checkedId == R.id.r_female) {
                    gender="female";
                }
            }

        });



        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(Singup.this, Login.class);
                startActivity(i);
            }
        });
    }
    public void validate()
    {

        String u_email = email.getText().toString();
        String u_pass = pass.getText().toString();


        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
        if (u_email.isEmpty() || u_email.length() < 3 || !u_email.matches(emailPattern)) {
            email.setError("Email Required");
            email.findFocus();
            valid = false;
        }

        else if (u_pass.isEmpty() || u_pass.length() < 3) {
            pass.setError("at least 3 characters");
            pass.findFocus();
            valid = false;
        }

        else{
            callapi();
        }
    }
    public void callapi()
    {
        AndroidNetworking.post(Api.ROOT_URL+"biker/signup.php")

                .addBodyParameter("fname", fname.getText().toString())
                .addBodyParameter("lname", lname.getText().toString())
                .addBodyParameter("email", email.getText().toString())
                .addBodyParameter("password", pass.getText().toString())
                .addBodyParameter("gender",gender)
                .setTag("test")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            if(response.getString("error").equals("false"))
                            {
                                Toast.makeText(Singup.this, "Account Created", Toast.LENGTH_SHORT).show();

                                Intent intent = new Intent(Singup.this, Login.class);
                                startActivity(intent);
                            }
                            else if(response.getString("error").equals("true"))
                            {
                                Toast.makeText(Singup.this, "Email Already Registered", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }
}