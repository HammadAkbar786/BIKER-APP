package com.example.bikerapp.User;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.example.bikerapp.Api;
import com.example.bikerapp.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class All_UserPosts extends AppCompatActivity {
    public static String id;
    ArrayList<Model_class> itemarrayList;
    RecyclerView item_recyclerView;
    List<String> shop_item_image=new ArrayList<String>();
    //    int shop_item_image[]={R.drawable.random2,R.drawable.random1,R.drawable.random4};
    List<String> shop_item_price=new ArrayList<String>();
    List<String> shop_item_category=new ArrayList<String>();
    List<String> shop_item_name=new ArrayList<String>();
    List<String> shop_item_id=new ArrayList<String>();
    List<String> shop_item_details=new ArrayList<String>();
    Spinner category;
    String selectedvalue;
    List<String> spinnerArray =  new ArrayList<String>();
    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_user_posts);
        category=findViewById(R.id.category_spinner);
        item_recyclerView = findViewById(R.id.lv_user_posts);
        Bundle b=getIntent().getExtras();
        id=b.getString("id");
        All_Posts.data="";

        showcategories();
        spinnerArray.add("***Select***");

        category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                selectedvalue=parent.getItemAtPosition(position).toString();
                if(!(selectedvalue.equals("***Select***"))) {
                    showitems(selectedvalue);
                }
                else
                {
                    showproducts();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });





    }
    public void showcategories()
    {
        AndroidNetworking.post(Api.ROOT_URL+"biker/getallcategories.php")
                .setTag("test")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            Toast.makeText(All_UserPosts.this, response+"", Toast.LENGTH_SHORT).show();
                            for (int i = 0; i < response.getJSONArray("allcategories").length(); i++)
                            {

                                spinnerArray.add(response.getJSONArray("allcategories").getJSONObject(i).getString("categories"));
                            }

                            adapter= new ArrayAdapter<String>(All_UserPosts.this, android.R.layout.simple_spinner_item, spinnerArray);

                            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                            category.setAdapter(adapter);

                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }

    public void showshoplist()
    {

        itemarrayList = new ArrayList<>();

        item_recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false));
        item_recyclerView.setItemAnimator(new DefaultItemAnimator());

        for (int i = 0; i < shop_item_image.size(); i++) {
            Model_class itemModel = new Model_class();
            itemModel.setImageUrl(shop_item_image.get(i));
            itemModel.setPrice(shop_item_price.get(i));
            itemModel.setName( shop_item_name.get(i));
            itemModel.setId( shop_item_id.get(i));
            itemModel.setCategory( shop_item_category.get(i));
            itemModel.setDescription(shop_item_details.get(i));
            //add in array list
            itemarrayList.add(itemModel);
        }

        Posts_Adapter winteritemuperadapter = new Posts_Adapter(getApplicationContext(), itemarrayList);
        item_recyclerView.setAdapter(winteritemuperadapter);
    }
    public void showproducts()
    {
        AndroidNetworking.post(Api.ROOT_URL+"biker/myposts.php")
                .addBodyParameter("posted_by", id)

                .setTag("test")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            Toast.makeText(All_UserPosts.this, response+"", Toast.LENGTH_SHORT).show();
                            for (int i = 0; i < response.getJSONArray("myposts").length(); i++)
                            {
                                shop_item_image.add(Api.ROOT_URL+"biker/"+response.getJSONArray("myposts").getJSONObject(i).getString("image_location"));
                                shop_item_price.add(response.getJSONArray("myposts").getJSONObject(i).getString("price"));

                                shop_item_name.add(response.getJSONArray("myposts").getJSONObject(i).getString("name"));
                                shop_item_id.add(response.getJSONArray("myposts").getJSONObject(i).getString("id"));
                                shop_item_category.add(response.getJSONArray("myposts").getJSONObject(i).getString("category"));
                                shop_item_details.add(response.getJSONArray("myposts").getJSONObject(i).getString("details"));

                            }

                            showshoplist();
                            shop_item_image.clear();
                            shop_item_category.clear();
                            shop_item_price.clear();
                            shop_item_id.clear();
                            shop_item_category.clear();
                            shop_item_details.clear();
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }
    public void showitems(String selectedvalue)
    {
        AndroidNetworking.post(Api.ROOT_URL+"biker/getbycategoryandid.php")
                .addBodyParameter("category", selectedvalue)
                .addBodyParameter("posted_by", All_UserPosts.id)
                .setTag("test")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
//                            if(response.getJSONArray("postbycategory").getJSONObject(0).getString("success").equals("0"))
//                            {
//                                Toast.makeText(All_UserPosts.this, "Nothing Found", Toast.LENGTH_SHORT).show();
//                            }
                            for (int i = 0; i < response.getJSONArray("postbycategory").length(); i++)
                            {
                                shop_item_image.add(Api.ROOT_URL+"biker/"+response.getJSONArray("postbycategory").getJSONObject(i).getString("image_location"));
                                shop_item_price.add(response.getJSONArray("postbycategory").getJSONObject(i).getString("price"));

                                shop_item_name.add(response.getJSONArray("postbycategory").getJSONObject(i).getString("name"));
                                shop_item_id.add(response.getJSONArray("postbycategory").getJSONObject(i).getString("id"));
                                shop_item_category.add(response.getJSONArray("postbycategory").getJSONObject(i).getString("category"));
                                shop_item_details.add(response.getJSONArray("postbycategory").getJSONObject(i).getString("details"));

                            }

                            showshoplist();
                            shop_item_image.clear();
                            shop_item_category.clear();
                            shop_item_price.clear();
                            shop_item_id.clear();
                            shop_item_category.clear();
                            shop_item_details.clear();
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }
}