package com.example.bikerapp.Admin;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.example.bikerapp.Api;
import com.example.bikerapp.R;
import com.example.bikerapp.UpdatePost;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ManageCategories extends AppCompatActivity {
    ArrayList<String>list=new ArrayList<>();
    ListView lv;
    ArrayAdapter aa;
    Button add;
    EditText ed_category;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_categories2);
       lv = findViewById(R.id.lv_cat);
       add=findViewById(R.id.add_category);
        ed_category=findViewById(R.id.ed_category);



       add.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               String cat=ed_category.getText().toString();
               if(cat.equals("")){
                   Toast.makeText(ManageCategories.this, "Enter Something to Add", Toast.LENGTH_SHORT).show();
               }
               else
               {
                   addcategory(cat);
               }
           }
       });
showproducts();
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(ManageCategories.this, parent.getItemAtPosition(position).toString()+"", Toast.LENGTH_SHORT).show();
                AlertDialog.Builder builder = new AlertDialog.Builder(ManageCategories.this);
                builder.setTitle("Do you want to delete");
                builder.setItems(new CharSequence[]
                                {"Delete", "Cancel"},
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // The 'which' argument contains the index position
                                // of the selected item
                                switch (which) {
                                    case 0:
                                        deletecategory(parent.getItemAtPosition(position).toString());



                                        break;
                                    case 1:

                                        break;


                                }
                            }
                        });
                builder.create().show();



            }
        });



    }
    public void addcategory(String category)
    {
        AndroidNetworking.post(Api.ROOT_URL+"biker/addcategories.php")
                .addBodyParameter("category", category)
                .setTag("test")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {

                        Toast.makeText(ManageCategories.this, "New Category Add", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(ManageCategories.this, ManageCategories.class);
                        startActivity(intent);

                    }

                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }
    public void deletecategory(String category)
    {
        AndroidNetworking.post(Api.ROOT_URL+"biker/deletecategory.php")
                .addBodyParameter("category", category)
                .setTag("test")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {

                        Toast.makeText(ManageCategories.this, "Item has been deleted", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(ManageCategories.this, ManageCategories.class);
                        startActivity(intent);

                    }

                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }
    public void showproducts()
    {
        AndroidNetworking.post(Api.ROOT_URL+"biker/getallcategories.php")


                .setTag("test")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            Toast.makeText(ManageCategories.this, response+"", Toast.LENGTH_SHORT).show();
                            for (int i = 0; i < response.getJSONArray("allcategories").length(); i++)
                            {
                                list.add(response.getJSONArray("allcategories").getJSONObject(i).getString("categories"));

                            }
                            aa=new ArrayAdapter(ManageCategories.this,android.R.layout.simple_list_item_1,list);  //Check this
                            lv.setAdapter(aa);
                        }
                        catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(ManageCategories.this, Admin.class);
        startActivity(intent);
    }
}