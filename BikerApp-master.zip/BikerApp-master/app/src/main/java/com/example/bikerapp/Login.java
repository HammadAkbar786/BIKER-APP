package com.example.bikerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.example.bikerapp.Admin.Admin;
import com.example.bikerapp.User.UserMain;

import org.json.JSONException;
import org.json.JSONObject;

public class Login extends AppCompatActivity {
    EditText user,pass;
    Button login;
    TextView singup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login=findViewById(R.id.login_btn);
        singup=findViewById(R.id.signup_btn);
        user=findViewById(R.id.user);
        pass=findViewById(R.id.pass);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(user.getText().toString().equals("admin") && pass.getText().toString().equals("admin"))
                {
                    Intent i=new Intent(Login.this, Admin.class);
                    startActivity(i);
                }
                else{
                    callapi();
                }

            }
        });
        singup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(Login.this, Singup.class);
                startActivity(i);
            }
        });
    }
    public void callapi()
    {
        AndroidNetworking.post(Api.ROOT_URL+"biker/login.php")
                .addBodyParameter("email", user.getText().toString())
                .addBodyParameter("password", pass.getText().toString())

                .setTag("test")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
//                        Toast.makeText(LoginActivity.this, ""+response, Toast.LENGTH_SHORT).show();
                        try {
                            if(response.getString("error").equals("false"))
                            {
                                Toast.makeText(Login.this, "Invalid email/password", Toast.LENGTH_SHORT).show();
                            }
                            else if (response.getString("error").equals("true")){
                                Intent i = new Intent(Login.this, UserMain.class);
                                i.putExtra("id",response.getJSONObject("user").getString("id"));
                                Toast.makeText(Login.this, response+"", Toast.LENGTH_SHORT).show();
//                            i.putExtra("email",response.getJSONObject("user").getString("email"));
//                            i.putExtra("name",response.getJSONObject("user").getString("name"));
//                            i.putExtra("city",response.getJSONObject("user").getString("city"));
//                            i.putExtra("gender",response.getJSONObject("user").getString("gender"));
//                            i.putExtra("contact",response.getJSONObject("user").getString("contact"))
                                startActivity(i);

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        //                        Intent i = new Intent(LoginActivity.this, MainActivity.class);
//                        i.putExtra("key","this");
//                        startActivity(i);
                    }
                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }
}