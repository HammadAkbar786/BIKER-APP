package com.example.bikerapp.Admin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.bikerapp.R;

public class Show_post extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_post);
    }
}